package com.khai.devision302.webinar.api.rest.impl;

import com.khai.devision302.webinar.api.rest.UserControllerDoc;
import com.khai.devision302.webinar.api.rest.maper.UserBusinessToApi;
import com.khai.devision302.webinar.api.rest.model.UserDto;
import com.khai.devision302.webinar.system.dao.UserRepository;
import com.khai.devision302.webinar.system.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
public class UserController implements UserControllerDoc {

    @Autowired
    private UserService service;
    @Autowired
    private UserBusinessToApi mapper;

    @Override
    @GetMapping("/users")
    public String getUserList(Model model) {
        model.addAttribute("users", service.getUsers().stream().map(mapper::toApi));
        return "user-list";
    }

    @Override
    @PostMapping("/users")
    public String addUser(UserDto userDto) {
        service.createUser(mapper.toBusiness(userDto));
        return "redirect:/users";
    }

    @GetMapping("/users/new")
    public String addUserForm(UserDto userDto, BindingResult result, Model model) {
        return "add-user";
    }

    @PutMapping("/users/{id}")
    public String updateUser(@PathVariable("id") long id, UserDto userDto) {
        service.updateUser(mapper.toBusiness(userDto));
        return "redirect:/users";
    }

    @GetMapping("/users/{id}")
    public String updateUserForm(@PathVariable("id") long id, Model model) {
        UserDto userDto = mapper.toApi(service.getUser(id));
        model.addAttribute("userDto", userDto);
        return "update-user";
    }

    @DeleteMapping("/users/{id}")
    public String deleteUser(@PathVariable("id") long id, Model model) {
        service.deleteUser(id);
        return "redirect:/users";
    }
}
