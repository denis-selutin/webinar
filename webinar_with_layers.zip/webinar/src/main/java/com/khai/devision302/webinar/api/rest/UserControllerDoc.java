package com.khai.devision302.webinar.api.rest;

import com.khai.devision302.webinar.api.rest.model.UserDto;
import org.springframework.ui.Model;

public interface UserControllerDoc {
    String getUserList(Model model);
    String addUser(UserDto userDto);
}
