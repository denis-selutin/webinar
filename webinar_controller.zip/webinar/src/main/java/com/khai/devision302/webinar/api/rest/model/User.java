package com.khai.devision302.webinar.api.rest.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class User {
    Long id;
    String firstName;
    String lastName;
    String nickname;
    String email;
}
