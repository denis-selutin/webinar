package com.khai.devision302.webinar.api.rest;

import com.khai.devision302.webinar.api.rest.model.User;
import org.springframework.ui.Model;

public interface UserControllerDoc {
    String getUserList(Model model);
    String addUser(User user);
}
