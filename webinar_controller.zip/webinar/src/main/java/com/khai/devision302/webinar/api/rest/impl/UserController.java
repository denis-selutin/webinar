package com.khai.devision302.webinar.api.rest.impl;

import com.khai.devision302.webinar.api.rest.UserControllerDoc;
import com.khai.devision302.webinar.api.rest.model.User;
import java.util.Arrays;
import java.util.Collections;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class UserController implements UserControllerDoc {

    @Override
    @GetMapping("/users")
    public String getUserList(Model model) {
        model.addAttribute("users", Arrays.asList(
                User.builder().nickname("test").id(1l).email("test@gmail.com").build()
        ));
        return "user-list";
    }

    @Override
    @PostMapping("/users")
    public String addUser(User user) {
        return "redirect:/users";
    }
}
