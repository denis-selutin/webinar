package com.khai.devision302.webinar.system.service;

import com.khai.devision302.webinar.system.model.User;

import java.util.List;

public interface UserService {
    User getUser(Long id);
    User createUser(User user);
    User updateUser(User user);
    void deleteUser(Long id);
    List<User> getUsers();
}
