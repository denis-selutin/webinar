package com.khai.devision302.webinar.api.rest.maper;


import com.khai.devision302.webinar.api.rest.model.UserDto;
import com.khai.devision302.webinar.system.model.User;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface UserBusinessToApi {
    User toBusiness(UserDto user);

    UserDto toApi(User user);
}
