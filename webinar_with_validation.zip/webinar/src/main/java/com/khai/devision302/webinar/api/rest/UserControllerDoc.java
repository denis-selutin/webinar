package com.khai.devision302.webinar.api.rest;

import com.khai.devision302.webinar.api.rest.model.UserDto;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

public interface UserControllerDoc {
    String getUserList(Model model);
}
