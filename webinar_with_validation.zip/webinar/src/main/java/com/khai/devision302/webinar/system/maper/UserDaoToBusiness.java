package com.khai.devision302.webinar.system.maper;


import com.khai.devision302.webinar.system.dao.model.UserDao;
import com.khai.devision302.webinar.system.model.User;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface UserDaoToBusiness {
     UserDao toDao(User user);
     User toBusiness(UserDao user);
}
