package com.khai.devision302.webinar.system.service.impl;

import com.khai.devision302.webinar.system.dao.UserRepository;
import com.khai.devision302.webinar.system.dao.model.UserDao;
import com.khai.devision302.webinar.system.maper.UserDaoToBusiness;
import com.khai.devision302.webinar.system.model.User;
import com.khai.devision302.webinar.system.service.UserService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.StreamSupport;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserDaoToBusiness mapper;

    @Autowired
    private UserRepository repository;

    @Override
    public User getUser(Long id) {
        return mapper.toBusiness(repository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid user Id:" + id)));
    }

    @Override
    public User createUser(User user) {
        return mapper.toBusiness(repository.save(mapper.toDao(user)));
    }

    @Override
    public User updateUser(User user) {
        UserDao userDao = repository.findById(user.getId())
                .orElseThrow(() -> new IllegalArgumentException("Invalid user Id:" + user.getId()));
        userDao.setEmail(user.getEmail());
        userDao.setFirstName(user.getFirstName());
        userDao.setLastName(user.getLastName());
        userDao.setNickName(user.getNickName());
        return mapper.toBusiness(repository.save(userDao));
    }

    @Override
    public void deleteUser(Long id) {
        repository.deleteById(id);
    }

    @Override
    public List<User> getUsers() {
        return StreamSupport.stream(repository.findAll().spliterator(), false)
                .map(mapper::toBusiness)
                .toList();
    }
}
