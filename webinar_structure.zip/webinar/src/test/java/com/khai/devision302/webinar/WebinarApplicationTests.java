package com.khai.devision302.webinar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebinarApplicationTests {

	@Test
	void contextLoads() {
	}

}
