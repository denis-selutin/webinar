package com.khai.devision302.webinar.system.dao;

import com.khai.devision302.webinar.api.rest.model.User;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends CrudRepository<User, Long> {}
