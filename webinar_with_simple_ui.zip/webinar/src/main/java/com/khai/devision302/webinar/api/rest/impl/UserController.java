package com.khai.devision302.webinar.api.rest.impl;

import com.khai.devision302.webinar.api.rest.UserControllerDoc;
import com.khai.devision302.webinar.api.rest.model.User;
import com.khai.devision302.webinar.system.dao.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
public class UserController implements UserControllerDoc {

    @Autowired
    private UserRepository repository;

    @Override
    @GetMapping("/users")
    public String getUserList(Model model) {
        model.addAttribute("users", repository.findAll());
        return "user-list";
    }

    @Override
    @PostMapping("/users")
    public String addUser(User user) {
        repository.save(user);
        return "redirect:/users";
    }

    @GetMapping("/users/new")
    public String addUserForm(User user, BindingResult result, Model model) {
        return "add-user";
    }

    @PutMapping("/users/{id}")
    public String updateUser(@PathVariable("id") long id, User user) {
        User targetUser = repository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid user Id:" + id));
        targetUser.setEmail(user.getEmail());
        targetUser.setFirstName(user.getFirstName());
        targetUser.setLastName(user.getLastName());
        targetUser.setNickName(user.getNickName());
        repository.save(targetUser);
        return "redirect:/users";
    }

    @GetMapping("/users/{id}")
    public String updateUserForm(@PathVariable("id") long id, Model model) {
        User user = repository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid user Id:" + id));

        model.addAttribute("user", user);
        return "update-user";
    }

    @DeleteMapping("/users/{id}")
    public String deleteUser(@PathVariable("id") long id, Model model) {
        User user = repository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid user Id:" + id));
        repository.delete(user);
        return "redirect:/users";
    }
}
